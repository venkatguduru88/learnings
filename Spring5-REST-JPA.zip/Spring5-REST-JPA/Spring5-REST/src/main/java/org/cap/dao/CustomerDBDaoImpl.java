package org.cap.dao;

import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.cap.model.Customer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("customerDbDao")
@Transactional
public class CustomerDBDaoImpl implements ICustomerDao {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Customer> getAllCustomers() {
		
		return entityManager.createQuery("from Customer").getResultList();
	}

	@Override
	public List<Customer> createCustomer(Customer customer) {
		
		entityManager.persist(customer);
		return getAllCustomers();
	}

	@Override
	public Customer updateCustomer(Customer customer,int customerID) {
		// TODO Auto-generated method stub
		Customer cust=entityManager.find(Customer.class, customerID);
		cust.setAccount(customer.getAccount());
		cust.setContactNo(customer.getContactNo());
		cust.setCustomerName(customer.getCustomerName());
		entityManager.persist(cust);
		return cust;
	}

	@Override
	public String deleteCustomer(int customerID) {
		// TODO Auto-generated method stub
		Query  query=entityManager.createQuery("delete from Customer where customerId=:id");
		entityManager.setProperty("id", customerID);
		int result  =query.executeUpdate();
		if(result == 1){
			return "deleted record from db";
			
		}
		else
			return "";
		
	}

	@Override
	public Customer updateCustomerUsingPatch(Map<String, Object> updates, int customerID) {
		// TODO Auto-generated method stub
		Customer cust=entityManager.find(Customer.class, customerID);
		if(updates.containsKey("customerName"))
			cust.setCustomerName((String)updates.get("customerName"));
		if(updates.containsKey("contactNo"))
			cust.setCustomerName((String)updates.get("contactNo"));
		
		entityManager.persist(cust);
		return cust;
	}

}
