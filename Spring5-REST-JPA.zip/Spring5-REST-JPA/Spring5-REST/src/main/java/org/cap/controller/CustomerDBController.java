package org.cap.controller;

import java.util.List;
import java.util.Map;

import org.cap.dao.ICustomerDao;
import org.cap.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/cust/v2")
public class CustomerDBController {
	@Autowired
	private ICustomerDao customerDbDao;
	
	@PostMapping("/customers")
	public ResponseEntity<List<Customer>> createCustomer(
			@RequestBody Customer customer){
		List<Customer> customers= customerDbDao.createCustomer(customer);
		if(customers==null || customers.isEmpty()) {
			return new ResponseEntity("Sorry! Customer Details Not Avilable!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Customer>>(customers, 
				HttpStatus.OK);
	}
	
	@GetMapping("/customers")
	public ResponseEntity<List<Customer>> getAllCustomers(){
		List<Customer> customers= customerDbDao.getAllCustomers();
		if(customers==null || customers.isEmpty()) {
			return new ResponseEntity("Sorry! Customer Details Not Avilable!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Customer>>(customers, 
				HttpStatus.OK);
	}
	
	@PutMapping("/customers/{id}")
	public ResponseEntity<Customer> updateCustomers(@RequestBody Customer customer,
			@PathVariable int id){
		customer =customerDbDao.updateCustomer(customer,id);
		
		return new ResponseEntity<Customer>(customer, 
				HttpStatus.OK);
	}
	
	@DeleteMapping("/customers/{id}")
	public ResponseEntity<String> deleteCustomer(@PathVariable int id){
		String msg =customerDbDao.deleteCustomer(id);
		
		return new ResponseEntity<String>(msg, 
				HttpStatus.OK);
	}
	
	@PatchMapping("/customers/{id}")
	public ResponseEntity<Customer> updateUsingPatchCustomers(@RequestBody Map<String,Object> updates,
			@PathVariable int id){
		Customer customer =customerDbDao.updateCustomerUsingPatch(updates,id);
		
		return new ResponseEntity<Customer>(customer, 
				HttpStatus.OK);
	}

}
