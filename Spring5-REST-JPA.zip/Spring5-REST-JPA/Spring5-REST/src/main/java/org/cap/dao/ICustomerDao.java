package org.cap.dao;

import java.util.List;
import java.util.Map;

import org.cap.model.Customer;

public interface ICustomerDao {
	
	public List<Customer> getAllCustomers();

	public List<Customer> createCustomer(Customer customer);
	
	public Customer updateCustomer(Customer customer,int customerID);
	
	public Customer updateCustomerUsingPatch(Map<String,Object> updates,int customerID);
	
	public String deleteCustomer(int customerID);

}
