package org.cap.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
@Entity
@SequenceGenerator(name = "comp_seq",initialValue = 111 ,allocationSize = 10)
public class Company {
	
	@Id
	@GeneratedValue(generator = "comp_seq",strategy = GenerationType.SEQUENCE)
	private int companyId;
	private String companyName;
	
	

	@OneToMany(targetEntity = Employee.class,mappedBy = "company")
	private List<Employee> employees=new ArrayList<Employee>();
	
	public Company( String companyName) {
		super();
		
		this.companyName = companyName;
	}	
	
	public Company(int companyId, String companyName) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
	}
	public Company() {
		super();
	}
	
	public List<Employee> getEmployees() {
		return employees;
	}
	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	public int getCompanyId() {
		return companyId;
	}
	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	

}
