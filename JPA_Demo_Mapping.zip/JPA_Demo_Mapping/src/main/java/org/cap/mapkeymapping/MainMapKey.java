package org.cap.mapkeymapping;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainMapKey {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("xe");
		
		EntityManager entityManager=emf.createEntityManager();
		
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
		State s =new State();
		s.setId(1);
		s.setName("TN");
		State s2 =new State();
		s2.setId(2);
		s2.setName("TS");
		State s3 =new State();
		s3.setId(3);
		s3.setName("AP");
		State s4 =new State();
		s4.setId(4);
		s4.setName("KA");
		
		Map<Integer,State> stateMap=new LinkedHashMap<>();
		stateMap.put(1, s);
		stateMap.put(2, s2);
		stateMap.put(3, s3);
		stateMap.put(4, s4);
		
		Country c= new Country();
		c.setId(1);
		c.setName("INDIA");
		c.setStates(stateMap);		    
		    
		    
		    entityManager.persist(c);
		    			
			
		transaction.commit();
		entityManager.close();
		emf.close();
	
	}

}
