package org.cap.manytomanymap;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Library {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int b_id;
	private String b_name;
	@ManyToMany(targetEntity = Student.class)
	private List<Student> student;

	public Library(int b_id, String b_name, List<Student> student) {
		super();
		this.b_id = b_id;
		this.b_name = b_name;
		this.student = student;
	}

	public Library() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getB_id() {
		return b_id;
	}

	public void ListB_id(int b_id) {
		this.b_id = b_id;
	}

	public String getB_name() {
		return b_name;
	}

	public void ListB_name(String b_name) {
		this.b_name = b_name;
	}

	public List<Student> getStudent() {
		return student;
	}

	public void setStudent(List<Student> student) {
		this.student = student;
	}

	
}